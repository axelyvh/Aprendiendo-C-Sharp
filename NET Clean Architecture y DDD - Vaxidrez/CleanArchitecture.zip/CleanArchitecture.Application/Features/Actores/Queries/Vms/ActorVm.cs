﻿namespace CleanArchitecture.Application.Features.Actores.Queries.Vms
{
    public class ActorVm
    {
        public string? Nombre { get; set; }
        public string? Apellido { get; set; }
    }
}
